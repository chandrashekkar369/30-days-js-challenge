//Activity#04
console.log("\nActivity#04");
let num3 = 455;
console.log("initial value of num3=>", num3);
num3 = 766;
console.log("value of num3 after reassigning=>", num3);

//Activity#05
console.log("\nActivity#05");
const num4 = 455;
console.log("initial value of num3=>", num3);
// num4 = 766;
// console.log("value of num3 after reassigning=>", num3); //gives "TypeError: Assignment to constant variable."
